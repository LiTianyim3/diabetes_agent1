import json
import logging
import gradio as gr
from langchain.agents import Tool, initialize_agent, AgentType
from client.zhipu_llm import ZhipuLLM
from tools.lab_report_parser import parse_lab_report_text
from tools.symptom_questionnaire import run_questionnaire
from tools.diabetes_classifier import classify_diabetes
from tools.severity_scoring import score_severity
from tools.nutrition_advice import gen_nutrition_advice
from tools.exercise_advice import gen_exercise_advice

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)

# 初始化智谱 AI LLM 和 Agent
llm = ZhipuLLM()
agent = initialize_agent(
    [
        Tool("parse_lab", func=parse_lab_report_text,   description="解析检验报告文本"),
        Tool("classify_dm", func=classify_diabetes,     description="判断是否糖尿病"),
        Tool("score_sev", func=score_severity,          description="分级：轻/中/重"),
        Tool("nutrition", func=gen_nutrition_advice,    description="生成营养建议"),
        Tool("exercise", func=gen_exercise_advice,      description="生成运动建议"),
    ],
    llm,
    agent=AgentType.OPENAI_FUNCTIONS,
    verbose=False
)

# 解析报告摘要
def parse_report(report_text: str) -> str:
    logger.info("parse_report called with report_text: %r", report_text)
    if not report_text:
        return ""
    # 提取并日志输出结构化数据
    data = parse_lab_report_text(report_text)
    logger.info("Extracted lab data: %s", data)
    # 拼接摘要 prompt
    lines = []
    if data.get("fasting_glucose") is not None:
        lines.append(f"- 空腹血糖: {data['fasting_glucose']} mmol/L")
    if data.get("hba1c") is not None:
        lines.append(f"- HbA1c: {data['hba1c']} %")
    if data.get("ogtt_2h") is not None:
        lines.append(f"- OGTT 2h 血糖: {data['ogtt_2h']} mmol/L")
    if data.get("bmi") is not None:
        lines.append(f"- BMI: {data['bmi']}")
    bullet_str = "\n".join(lines)
    prompt = (
        f"以下是患者的检查指标：\n{bullet_str}\n"
        "请用一段专业、简洁的自然语言，概括上述检查结果及潜在风险。"
    )
    logger.info("Summary prompt: %r", prompt)
    summary = llm._call(prompt)
    logger.info("Generated summary: %r", summary)
    return summary

# 回答用户疑问
def answer_question(report_summary, history, user_message):
    logger.info("answer_question called with report_summary: %r user_message: %r", report_summary, user_message)
    history_list = list(history) if history else []
    context = report_summary or ""
    prompt = (
        f"已知报告摘要：\n{context}\n"
        f"用户提问：{user_message}\n"
        "请基于上述信息给出专业回答。"
    )
    logger.info("Question prompt: %r", prompt)
    bot_msg = agent.run(prompt)
    logger.info("Agent response: %r", bot_msg)
    history_list.append([user_message, bot_msg])
    return history_list, history_list

# 构建 Gradio 界面
with gr.Blocks() as demo:
    gr.Markdown("## 糖医助手 🩸 — 报告摘要与疑问解答")
    with gr.Row():
        with gr.Column(scale=2):
            report_input = gr.Textbox(
                label="检验报告（纯文本）",
                placeholder="将检验报告文字粘贴在此处",
                lines=6
            )
            parse_btn = gr.Button("解析报告要点")
            summary_output = gr.Textbox(
                label="报告摘要",
                interactive=False,
                lines=6
            )
            user_input = gr.Textbox(
                label="请输入您的问题",
                placeholder="如：我最近口渴、多尿，有家族史",
                lines=2
            )
            send_btn = gr.Button("发送")
        with gr.Column(scale=3):
            chatbot = gr.Chatbot(label="对话记录")

    state = gr.State([])

    # 解析摘要
    parse_btn.click(
        fn=parse_report,
        inputs=[report_input],
        outputs=[summary_output]
    )
    # 发送疑问
    send_btn.click(
        fn=answer_question,
        inputs=[summary_output, state, user_input],
        outputs=[chatbot, state]
    )
    user_input.submit(
        fn=answer_question,
        inputs=[summary_output, state, user_input],
        outputs=[chatbot, state]
    )

if __name__ == "__main__":
    demo.launch(inbrowser=True)
