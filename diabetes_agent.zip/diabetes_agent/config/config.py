import os
from dotenv import load_dotenv
load_dotenv()  # 读取 .env

# 智谱AI
ZHIPU_API_KEY  = os.getenv("ZHIPU_API_KEY")
ZHIPU_API_BASE = os.getenv("ZHIPU_API_BASE")

# 知识图谱（可选）
KG_URI      = os.getenv("KG_URI")
KG_USER     = os.getenv("KG_USER")
KG_PASSWORD = os.getenv("KG_PASSWORD")
