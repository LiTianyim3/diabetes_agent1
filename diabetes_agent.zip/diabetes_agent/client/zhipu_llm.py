from langchain.llms.base import LLM
from pydantic import BaseModel
from zhipuai import ZhipuAI
import os

class ZhipuLLM(LLM, BaseModel):
    """
    LangChain LLM wrapper for ZhipuAI (智谱 AI) using the latest SDK.
    """
    api_key: str      = os.getenv("ZHIPU_API_KEY")
    base_url: str     = os.getenv("ZHIPU_API_BASE", "https://open.bigmodel.cn/api/paas/v4/")
    model: str        = "chatglm_pro"
    temperature: float = 0.0
    max_tokens: int    = 1024

    def _call(self, prompt: str, stop=None) -> str:
        # Initialize client with API key and base URL
        client = ZhipuAI(api_key=self.api_key, base_url=self.base_url)
        # Create a chat completion request
        response = client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        # Extract and return the content
        return response.choices[0].message.content

    @property
    def _identifying_params(self):
        return {"model": self.model}

    @property
    def _llm_type(self):
        return "zhipuai"
